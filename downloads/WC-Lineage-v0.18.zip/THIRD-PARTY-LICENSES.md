# WC Lineage: third-party license notices

WC Lineage is freeware. The single-file application (`index.html`) embeds the
third-party components listed below. This file satisfies their notice requirements
and travels with every distributed copy.

## sql.js 1.10.2

SQLite compiled to WebAssembly, with its JavaScript loader. Both parts are embedded
in `index.html`: the loader as an inline script, the WebAssembly binary as a
base64-encoded block. Project page: https://github.com/sql-js/sql.js

```
MIT license

Copyright (c) 2017 sql.js authors (see AUTHORS)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

## SQLite

SQLite, the database engine that sql.js compiles to WebAssembly, is in the
public domain and requires no license or attribution:
https://www.sqlite.org/copyright.html

## Pride flag color specifications

The flag stripe colors are public-domain community design specifications.
No copyrighted Warriors text or art is embedded; all character content is
user-created.
