# WC Lineage · Warrior Cats Family Trees (v0.14)

A local-first, browser-based ancestry and relationship tool for the Warrior Cats RP
community. Functional reference: **Family Echo** (behavior and workflow only; no code,
art, or branding reused). Built from scratch as a single self-contained HTML file.

## What it does

- **Fully offline (v0.14).** The SQLite engine now ships inside `index.html`: no
  first-run download, no CDN, nothing to cache. Open the file and it works,
  internet or not. (License notices for the embedded engine travel in
  `THIRD-PARTY-LICENSES.md`.)
- **Projects → Trees → Cats.** A project groups related trees and defines its own set of
  clans (seeded with editable canon-inspired presets: ThunderClan, RiverClan, WindClan,
  ShadowClan, SkyClan, StarClan, Dark Forest, Kittypet/Outsider). You can run any number
  of projects side by side.
- **Pin cats in place (v0.11).** A 📌 **Pin position** toggle in the profile
  freezes a cat's canvas placement: ⟲ Tidy resets everything *except* pinned cats,
  and a line you've hand-routed keeps its channel and moon-label spot when both of
  its cats are pinned. Pinned tiles wear a small 📌 badge, still ride along with
  their family when the layout reflows, and the pin travels with copies, merges,
  and JSON export/import (it's per-copy, like positions). Dragging alone stays
  tidy-able, exactly as before; pinning is the deliberate act. A **📌 Hide pins**
  toolbar toggle (v0.11.1) hides all the badges when you want a clean canvas:
  display only, pins stay active and Tidy still honors them; the choice is
  remembered like the theme.
- **Mentors can be anyone (v0.10).** The profile's mentor picker is now a smart
  text box: start typing and the tree's cats are suggested: a name that matches a
  cat on the tree (any capitalization) links a normal mentor, and any other name is
  kept as an **off-tree** text mentor, because mentors aren't always on trees.
  Off-tree mentors get the same from–to apprenticeship moons, travel with JSON
  export/import, tree merges, and copy-to-new-tree, and are marked "off-tree" in
  the list so you can tell them from linked cats at a glance.
- **Widowed pairs draw with respect (v0.10).** A relationship still marked "mate"
  where either partner has died now renders as a **dashed line in the same color as
  an active mate line**: the breakup was involuntary, and the line style honors
  that. It's automatic (it follows the death moon / deceased flag; nothing to set),
  the profile row reads "widowed", and the moon label shows the span when the end
  moon is known. A pair separated *before* a death stays ex-styled (grey dashes).
- **The profile panel stops kicking you out (v0.10).** Adding a mentor, changing a
  relationship kind, or deleting a row used to rebuild the panel and collapse every
  section back to its defaults. The panel now remembers which sections you had open
  (and where you'd scrolled) whenever it re-renders the same cat.
- **Profiles autosave when you navigate away (v0.9.1).** Clicking another cat, the
  empty canvas, another tree or project, entering select mode, loading the Sample,
  or closing the app saves the open profile's edits first; the Save button flashes
  **Saved ✓** so you can see it happened. A brand-new cat's first save happens the
  same way, so nothing you type is ever lost; autosaves sync 🔗-linked copies
  exactly like a manual save, and the Save button still works for saving on the
  spot. (This retires v0.7's greyed-out link buttons: with autosave, pressing them
  can't lose anything, so they stay enabled.)
- **Merge trees (v0.9).** When two trees need to connect (say, Verbenastar in one
  tree and Max in another), open ⚙ Trees and press **⤵ merge…** on the source tree:
  pick the target, review the summary, and its cats and relationships move across;
  after which any two cats can be linked as mates, parents or mentors. Two options,
  both per merge: **consolidate 🔗-linked duplicates** (each "same character" pair
  becomes one cat: the target's copy is kept and inherits the incoming copy's
  relationships; duplicates are cleaned up; cats that merely share a name stay
  separate) and **delete the emptied source tree** (untick to keep it as a shell).
  🔗 links to other trees survive and follow the kept cat.
- **Copy a portion of a tree (v0.8; existing-tree destinations v0.12).** The ⬚
  Select button enters select mode: drag a box around cats, click to add or remove
  one, and ＋ Kin grows the selection with the selected cats' mates and
  descendants. "Copy to tree…" then copies the
  selection (cats with their full profiles plus every relationship *between* them)
  into a brand-new tree or, as of v0.12, into **any other existing tree** in the
  project, picked right in the dialog (nothing is moved; the source tree itself
  isn't offered, since copying a family onto itself is almost always an accident).
  When the destination is an existing tree, a 🧩 **connect** option (v0.13, on by
  default) makes the copy intelligent: a selected cat that's already there (a 🔗
  "same character" link always counts, and an exact name match counts when it's
  unambiguous) is **not duplicated**; instead, mates, parents/kits and mentorships
  from the copy re-attach through the target's existing cats, and exact-duplicate
  relationships are skipped. So copying a mated pair into a tree that already holds
  one of them yields one new cat, correctly mated to the resident. Ambiguous names
  (two residents with the same name, or a name repeated inside your selection) stay
  separate, and a name match never creates a 🔗 link or touches the resident's
  profile; it only routes relationships. Untick 🧩 for plain duplicating copies. A pre-checked option 🔗-links each copy to its original as
  the same character, so profile edits sync both ways; untick it for independent
  copies. Esc leaves select mode.
- **Pick which trees sit side by side (v0.8).** The Tree dropdown keeps 🌳 All trees
  and gains **🗂 Pick trees…**, a checklist that shows exactly the trees you tick,
  side by side (sharing one moon ruler in timeline mode). The choice applies live,
  reads as "🗂 2 of 5 trees" in the dropdown, and is remembered per project.
- **Lines never cut through cats (v0.7.2).** Relationship routing is now
  obstacle-aware: horizontal channels sink until they cross no tile, vertical runs
  sidestep into clear lanes (jogging under flanking kin when needed), a drop whose
  union point sits level with or below a kit enters the kit's bottom edge, and the
  short mate bar falls back to an elbow if a tile is squeezed between the pair.
  Cats without a birth moon also spread far enough apart in timeline mode for the
  channels to breathe. Hand-dragged lines are still honored exactly as placed.
- **Families lay out as blocks (v0.7.1).** Auto-layout (and therefore ⟲ Tidy) now
  treats each connected family as its own block. Blocks pack left-to-right in creation
  order with a clear gap, so unrelated families never interleave, and a brand-new cat
  or a growing offshoot lands in fresh space at the right instead of threading through
  an existing tree.
- **No hidden tiles in timeline mode (v0.7.1).** Cats born a few moons apart could
  land exactly on top of each other (an unknown-parent stand-in could completely
  cover a kit). Overlapping tiles are now pushed apart sideways to a minimum
  clearance; litter-mates still share their row on purpose.
- **Litter-shared unknown parents (v0.7.1).** Giving the same unknown parent
  ("Outsider" or the same clan) to kits born the **same moon** from the **same known
  parent** reuses the existing stand-in instead of minting a duplicate. Kits born at
  different moons never collapse into an upstream stand-in; they get their own.
- **Drag-ordered clans (v0.7).** In ⚙ Projects & Clans, grab a clan row's ≡ handle and
  drag it to a new spot; the Clan dropdown on every profile follows the same order, new
  clans append at the end, and the order survives JSON export/import.
- **Project-wide current moon (v0.7).** The toolbar's Current moon belongs to the
  project now, not to each tree: every tree computes ages from the same "now", and the
  field stays editable in the All-trees overview. Existing databases migrate to the
  highest of their trees' moons so no cat's age goes backwards (old per-tree values are
  left in place, dormant).
- **Skills (v0.7).** The extended profile gains a Skills box (hunting, battle moves,
  herbs, swimming…), synced across linked copies and carried in project exports.
- **Paste a portrait (v0.7, fixed in v0.7.1).** Click the portrait picture, then press
  Ctrl+V to paste a copied screenshot (e.g. Win+Shift+S) straight onto the cat,
  downscaled exactly like a chosen file. The file picker still works too. (v0.7's
  listener sat on the picture element, which Chrome never delivers paste events to;
  it now listens at the document and acts only while the picture has focus.)
- **Unknown parents (v0.7).** ＋ Parent (sidebar button or double-click menu) now opens
  a chooser: a new named parent, or an unknown-parent stand-in named **"Outsider"** or
  after **any clan** (whichever the RP later decides). The stand-in is born 2 moons
  before the kit so it sits just above them on the timeline, wears the matching clan,
  and is joined to the kit's known parent by a purple dashed **unknown union** line.
  Mate rows have a mate / ex / unknown picker, so the union can also be set or cleared
  by hand. Rename the stand-in once the character is decided.
- **Editable parent kinds (v0.7).** Every Parents/Kits row now carries a biological /
  adopted / foster dropdown; adopted and foster lines draw dashed as always.
- **No more lost profiles (v0.7, superseded in v0.9.1).** v0.7 greyed the link/
  relationship buttons while a cat had unsaved edits; v0.9.1's navigate-away
  autosave removes the risk entirely, so the buttons now stay enabled.
- **Side-by-side overview (v0.7).** 🌳 All trees lays the project's trees out
  horizontally. With 🌙 Timeline on, every tree shares one moon ruler, so the same moon
  lines up straight across the whole project.
- **Flag-backed nodes.** Each cat's bubble is split diagonally: gender-identity flag on
  the top-left, sexuality flag on the bottom-right, with a portrait slot at the left of
  the bubble and the short profile (name, rank · clan, moons) on a readable scrim.
  13 gender and 13 sexuality flags included; unset halves fall back to neutral gray.
- **Moons timeline toggle (🌙).** Classic mode lays cats out in generation rows. Timeline
  mode repositions everything vertically by birth moon against a moon ruler; mate links
  are labeled with the moon they began (and ended, for exes).
- **Editable mate moons (v0.6.2).** Each mate row in the profile panel has 🌙 from–to
  inputs (the moon the pair became mates / separated) and an **ex** checkbox, saved as
  you type; the moon label and line style on the canvas update immediately. The number
  fields hide their spinner arrows (v0.6.4) so the full width is legible; type a value
  or use the keyboard arrow keys.
- **Relationships:** mates, ex-mates and widowed pairs (with start/end moons),
  parents/kits (biological, adopted, foster; non-biological links draw dashed),
  siblings, mentors (on-tree or free-text).
  Self-links, duplicate links, and ancestry cycles are blocked.
- **Multiple mentors (v0.3).** Each cat can have any number of mentors, each with
  optional apprenticeship start/end moons, edited in the profile panel. Apprentices are
  listed on the mentor's profile in turn.
- **Counters (v0.3).** The sidebar shows the member count for the current tree (and
  per-tree counts in overview); each cat's profile shows its descendant count with a
  biological breakdown (e.g. "6 descendants · 4 biological").
- **Tree description (v0.3).** Click empty canvas to see the tree's description in the
  sidebar and edit it in place; the sample tree ships with one.
- **Cross-tree character links (v0.5).** When the same character appears in several trees
  of a project, mark the copies as one character: a 🔗 badge appears on each copy (full
  bubbles and compact dots alike); click it to hop to the other copy. The profile gains
  a "🔗 Also in other trees" section listing every linked copy with visit/unlink buttons
  and a picker to create new links. Links live in the project, survive JSON export/import,
  and are how imported Family Echo trees show the characters they share.
- **Profile-sync across linked copies (v0.5.1).** Saving a linked cat's profile now
  propagates it to every copy in the link group (links are transitive: A–B plus B–C means
  all three sync). Everything on the profile syncs (name, flags, clan, rank, moons,
  deceased, appearance, history, portrait, notes) while per-copy state (position nudges,
  branch collapse, relationships) stays untouched. The toast confirms how many copies
  were updated.
- **Custom flags (v0.6).** The 🚩 toolbar button opens a flag manager: name a flag, pick
  its stripe colors (add/remove stripes with live preview), and choose whether it's a
  gender or sexuality flag. Custom flags appear in the profile dropdowns marked with ★
  and render on bubbles and dots exactly like the built-ins. They're global to your
  browser, and project JSON exports carry whichever custom flags the project's cats
  actually wear; importing recreates missing ones (matched by kind + name, never
  duplicated). Deleting a worn flag warns you first; those cats fall back to unset.
- **Project-wide search (v0.6).** A search box in the toolbar matches cat names *and*
  former names across every tree in the current project. Results show the cat, its tree,
  and deceased status; clicking one jumps straight to that cat. Esc clears.
- **PNG export (v0.6, fixed in v0.6.1).** **⇄ Share → PNG (whole tree, 2×)** renders the
  entire current tree, regardless of pan/zoom, to a crisp 2× PNG with the theme
  background and your creator credit baked in. The SVG snapshot of the current view is
  still there too. v0.6.1 makes both image exports XML-safe (special characters in names
  and notes no longer break them) and automatically lowers the PNG resolution on very
  large trees to stay inside browser canvas limits (a toast tells you when).
- **Resizable profile panel (v0.6, refined in v0.6.3).** Drag the border between canvas
  and sidebar to widen the panel (280–720 px); the width is remembered. Type size stays
  fixed: the extra width goes to the fields themselves, so a wider panel shows more per
  line. Text areas grow taller with it and relationship rows wrap instead of overflowing.
- **Field help on hover (v0.6.5).** Rest the mouse on any profile field and a small box
  explains it in plain language (what a moon is, what the flags color, and so on). The
  cursor turns to a **?** over anything with help. It hides while you're typing and
  never blocks the field you're editing.
- **Kits hang from the relationship line (v0.5.2).** When a kit's two parents share a
  mate line, its descent line now starts on that line's union point (the middle of the
  couple's bar, or of the routed channel run) instead of dropping from the parents'
  bubbles and passing through it. The hang point follows the mate line wherever it goes
  (moon-label channels, manual drags), so lineage can't visually cut past a couple and
  appear to descend from an unrelated cat. Single-parent kits still drop from their
  parent's bubble.
- **🔗 badge click fixed + tree chooser (v0.5.1).** Clicking the badge now reliably hops
  to the linked copy; if a cat has copies in several trees, a small menu opens at the
  click point listing each copy by tree so you pick where to go.
- **Deceased without a date (v0.5).** A cat can now be marked dead with no death moon
  (checkbox in the profile; a set death moon still implies it). Date-less dead cats fade,
  carry their afterlife overlay, and read "deceased" instead of an invented moon. Needed
  for Family Echo imports, which carry a deceased flag but no dates.
- **Family Echo importer (v0.5).** `wc-echo-import.html` (separate single-file tool)
  turns Family Echo CSV exports into a WC Lineage project JSON: one tree per CSV,
  same-named cats across files joined by cross-tree links (reviewable toggles),
  clan-named placeholder parents (e.g. "BassClan") converted to an *Unknown* cat carrying
  that clan, and unnamed members kept as *Unknown* only when they have kits.
- **Afterlife death markers (v0.4.1).** The † cross is gone. A dead cat's portrait
  instead carries a themed overlay keyed to its afterlife: a silver-blue starry veil
  for StarClan, murky gloom with claw scratches for the Dark Forest, drifting gray
  mist for Unknown/faded or Other. Dead cats with no afterlife set are marked by the
  fade alone. In ◉ compact mode, dots get a thin afterlife-colored ring instead.
- **Moon labels kept clear (v0.4).** Mate lines that carry a moon date/range route
  through a deeper channel below the row, and the label auto-shifts along the line so
  it never sits on a cat bubble, a parent line, or another label. A manually placed
  label always stays exactly where you put it.
- **Movable lines (v0.4).** Drag any relationship line up or down to shift its whole
  routing channel out of a crowded spot; the offset is saved per relationship.
- **Movable moon labels (v0.4).** Drag a moon label along its line to reposition it;
  the spot is saved. **⟲ Tidy** resets bubble nudges, line shifts, and label spots.
- **Branch collapse (v0.3).** Hover a cat to reveal a **−** handle beneath its bubble;
  click to fold its whole descendant branch into a "▸ N kin" badge. Hover the badge to
  see who's hidden, click to expand. Works in full and compact modes and persists.
- **Short profile** on the node/panel: name, pronouns, gender, sexuality, clan, rank,
  birth/death moon (age auto-computed from the tree's "current moon"), pelt line.
- **Extended profile** (collapsible): former names, appearance, personality, history,
  mentors, cause of death, afterlife (StarClan / Dark Forest / …), player notes, portrait.
- **Creator profile** (👤): display name, link, bio; stored locally, attached to exports
  so shared trees carry credit. No accounts, no telemetry.
- **Quick-add:** double-click any cat (or use the sidebar buttons) to add a pre-linked
  mate, kit, parent, or sibling. Adding a kit auto-links the sole current mate as
  co-parent. Quick-add keeps the current cat selected; the new kin appears on the
  canvas ready to click when you want it.
- **Movable bubbles.** Drag any cat to nudge it from its auto-layout spot; it snaps to
  align with nearby bubbles. Offsets are saved per cat. **⟲ Tidy** resets them for the
  current tree (or the whole project in overview). In timeline mode vertical position
  stays locked to birth moon; only sideways nudges apply.
- **Orthogonal relationship lines.** Mate and parent links route in clean horizontal/
  vertical channels between rows, so lines never run underneath bubbles. Line
  transparency is applied once across the whole layer (v0.3), so overlapping segments
  no longer stack into bright spots. Dead cats fade further for contrast.
- **Adaptive spacing.** Classic view packs generations tight for compact reading;
  timeline view spreads out for breathing room around the moon ruler.
- **Project overview (🌳 All trees).** Pick "All trees" in the tree selector to see every
  tree in the project stacked with headings; click any cat to jump into its tree.
- **◉ Compact mode.** Collapses bubbles to small split-flag "relationship points" with
  name labels: the whole structure at a glance, ideal for big trees and the overview.
- Dark mode default, light toggle (☀). A **Sample** button loads a three-generation
  demo project.

## How to run

Double-click `index.html`. **Runs fully offline:** as of v0.14 the SQLite engine
(sql.js WASM, ~1 MB) is embedded in the file alongside everything else. No internet,
no build step, no server, no install.

## Where data lives

In your browser: an SQLite database serialized to IndexedDB after every change
(per browser profile, per machine). Back up or move data via **⇄ Share**:

- **Download .db**: the whole database as a portable SQLite file (opens in DB Browser
  for SQLite and future companion tools). Import replaces everything, with a warning.
- **Export project JSON**: one project with your creator credit; importing adds it as a
  new project without touching existing data. This is the sharing format.
- **Snapshot SVG**: the current canvas view as a standalone image with a credit line.
- **PNG (whole tree, 2×)**: the full tree rasterized at double resolution with theme
  background and credit, ready to post or print.

### Importing from Family Echo

Open `wc-echo-import.html`, drop your Family Echo CSV exports on it (all of them at
once), review tree names, placeholder handling, and cross-tree matches, then download
the project JSON and import it in WC Lineage via **⇄ Share → Import project JSON**.
Runs fully offline. Family Echo exports carry no dates, so imported cats use the
deceased flag; add moons later as you flesh trees out.

## Schema (version 9, recorded in `meta.schema_version`)

```sql
meta          (key PK, value)                       -- schema_version, creator profile, prefs
projects      (id PK, name, description,
               current_moon,                        -- v7: the project's "now" (moved up from trees)
               created_at)
clans         (id PK, project_id FK, name, color, description,
               sort_order)                          -- v7: drag-chosen display order
trees         (id PK, project_id FK, name, description,
               current_moon)                        -- pre-v7 relic, dormant (never wiped)
cats          (id PK, tree_id FK, name, former_names, pronouns,
               gender, sexuality,                    -- keys into the flag catalogs
               clan_id FK, rank, birth_moon, death_moon,
               allegiance,                           -- v2: renamed from pelt; UI label is
                                                     --   "Pelt" again as of v0.6.6
               appearance, personality,
               skills,                               -- v7: what the cat is good at
               history,
               death_cause, afterlife, notes,
               portrait,                             -- downscaled base64 data URL
               pos_dx, pos_dy,                       -- v2: manual drag offsets from auto-layout
               branch_collapsed,                     -- v3: descendants folded into a badge
               deceased,                             -- v5: dead without a known moon
               pinned)                               -- v9: 📌 Tidy won't move this cat
relationships (id PK, tree_id FK, type,              -- 'mate' | 'parent' | 'mentor' (v3)
               cat_a FK, cat_b FK,                   -- mate: partners / parent: parent→child
                                                     -- mentor: mentor→apprentice
               kind,                                 -- mate: ''|'ex'|'unknown' (v7) / parent: biological|adopted|foster
               start_moon, end_moon,                 -- mentor: apprenticeship span
               route_off,                            -- v4: manual vertical shift of the line's channel
               label_t)                              -- v4: manual moon-label spot along the line (0..1, NULL = auto)
cat_links     (id PK, project_id FK,                 -- v5: "same character" links across trees
               cat_a FK, cat_b FK)
custom_flags  (id PK, kind,                          -- v6: 'gender' | 'sexuality'
               name, stripes)                        -- stripes = JSON array of hex colors;
                                                     -- cats reference them as 'custom:'+name
text_mentors  (id PK, cat_id FK,                     -- v8: mentors who aren't on any tree
               name, start_moon, end_moon)           --     free text + apprenticeship span
```

Older databases (and older project JSON exports) are migrated in place on load, never
wiped: v1→v2 renames `pelt` to `allegiance` and adds drag-offset columns; v2→v3 adds
`branch_collapsed` and converts the old single `mentor_id` column into `mentor`
relationship rows (enabling multiple mentors per cat); v3→v4 adds `route_off` and
`label_t` for manual line and label placement; v4→v5 adds the `cat_links` table and
the `deceased` flag, backfilled from existing death moons; v5→v6 adds the
`custom_flags` table; v6→v7 adds `projects.current_moon` (backfilled with the highest
of each project's tree moons), `clans.sort_order` (backfilled in creation order) and
`cats.skills`; v7→v8 adds the `text_mentors` table (free-text mentors who aren't on
any tree); v8→v9 adds `cats.pinned` (📌 pinned tiles that ⟲ Tidy leaves in place).

## Licensing notes

- Pride flag stripe colors are public-domain community specifications.
- No copyrighted Warriors text, art, or data is embedded; clan preset *names* are user-
  editable labels and all character content is user-created.
- sql.js is MIT-licensed and embedded in `index.html` (inline loader + base64
  WebAssembly binary). Full notice: `THIRD-PARTY-LICENSES.md`. SQLite itself is
  public domain.

## Notes for beta testers

- **This is a beta.** Everything you build is real data, but please export backups:
  **⇄ Share → Download .db** saves everything as one portable file you can re-import.
  Your data lives in your browser's storage (per browser, per machine); clearing
  "site data" for the page would erase it, so a periodic .db export is your safety net.
- **No internet needed.** As of v0.14 the database engine is embedded in
  `index.html`; the tool runs fully offline from the first open.
- Profiles autosave when you click away; the Save button flashes "Saved ✓".
- If something looks wrong, a screenshot plus the steps you took (and, if you're
  willing, an exported .db or project JSON) is the most useful bug report. Send
  feedback to whoever gave you this file.

## Known limits / next-iteration candidates

- Whole-DB import replaces rather than merges.
- No batch generation.
- Very tangled trees can still cross lines even with orthogonal routing; use drag + Tidy to hand-fix.
